# Galileia Capital — Site (VibeCoding)

Site estático (HTML + CSS + JS) pronto para subir no GitHub Pages.

## Como usar
1. Faça upload dos arquivos desta pasta para um repositório no GitHub.
2. Vá em **Settings → Pages**.
3. Em **Build and deployment**, escolha:
   - Source: **Deploy from a branch**
   - Branch: **main** / **root**
4. Salve. O GitHub vai gerar a URL do site.

## Personalizações rápidas
- E-mail: já está configurado como **pedro@galileiacapital.com.br**
- WhatsApp:
  - Abra `script.js` e preencha:
    ```js
    const PHONE = "5511999999999";
    ```
- Logo:
  - Substitua `assets/logo-galileia.jpeg` mantendo o mesmo nome, se quiser trocar.

Gerado em 2026-02-09.
