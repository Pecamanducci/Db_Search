// ====== CONFIGURE AQUI ======
const PHONE = ""; // Ex: 5511999999999 (Brasil + DDD + número). Deixe vazio se ainda não quiser WhatsApp.
const EMAIL = "pedro@galileiacapital.com.br";
const COMPANY = "Galileia Capital";

const WA_MESSAGE =
`Olá! Quero falar com a ${COMPANY}.
- Tenho (X) imóveis para locação / (X) obras para gestão
- Cidade:
- Objetivo (locação / reforma / obra / venda):
- Prazo:
Pode me enviar uma proposta com escopo e valores?`;

// ====== Helpers ======
const waLink = (msg) => `https://wa.me/${PHONE}?text=${encodeURIComponent(msg)}`;
const mailLink = (subject, body) => `mailto:${EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

// Menu mobile
const menuBtn = document.getElementById("menuBtn");
const mobileNav = document.getElementById("mobileNav");

menuBtn?.addEventListener("click", () => {
  const isOpen = menuBtn.getAttribute("aria-expanded") === "true";
  menuBtn.setAttribute("aria-expanded", String(!isOpen));
  mobileNav.hidden = isOpen;
});

// Email links
const emailLink = document.getElementById("emailLink");
const emailFooter = document.getElementById("emailFooter");
[emailLink, emailFooter].forEach(el => {
  if (!el) return;
  el.href = mailLink(`Contato - ${COMPANY}`, WA_MESSAGE);
  el.textContent = EMAIL;
});

// WhatsApp links (optional)
const waLinkEl = document.getElementById("waLink");
const floatWa = document.getElementById("floatWa");
if (!PHONE) {
  // Se não tiver número ainda, esconde os botões de WhatsApp para não quebrar.
  waLinkEl?.closest(".contact__card")?.classList.add("is-hidden");
  floatWa?.remove();
} else {
  waLinkEl.href = waLink(WA_MESSAGE);
  floatWa.href = waLink(WA_MESSAGE);
}

// Mensagem e copiar
const quickMsg = document.getElementById("quickMsg");
quickMsg.textContent = WA_MESSAGE;

const copyBtn = document.getElementById("copyBtn");
const toast = document.getElementById("toast");
copyBtn?.addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText(WA_MESSAGE);
    toast.textContent = "Copiado ✅";
    setTimeout(() => (toast.textContent = ""), 1400);
  } catch {
    toast.textContent = "Não foi possível copiar.";
    setTimeout(() => (toast.textContent = ""), 1400);
  }
});

// Ano no rodapé
document.getElementById("year").textContent = String(new Date().getFullYear());

// Esconde cards com WhatsApp se necessário
document.querySelectorAll(".is-hidden").forEach(el => el.style.display = "none");
